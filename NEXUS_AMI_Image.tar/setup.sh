#!/bin/bash

NEXUS_USERNAME="admin"
NEXUS_PASSWORD="admin123"

wget http://download.oracle.com/otn-pub/java/jdk/8u151-b12/e758a0de34e24606bca991d704f6dcbf/jdk-8u151-linux-x64.tar.gz



echo "Install Java JDK 8"
yum update -y
yum install -y java-1.8.0-openjdk-devel



sudo sh -c 'echo JAVA_HOME=\"/usr/java/jdk1.8.0_191-amd64/jre/bin\">> /etc/environment'

sudo sh -c 'echo JAVA_HOME=\"/usr/lib/jvm/jre-1.8.0-openjdk.x86_64/bin\">> /etc/environment'

echo "Install Nexus OSS"
cd /opt
mkdir nexus
cd /opt/nexus
wget http://download.sonatype.com/nexus/3/nexus-3.16.2-01-unix.tar.gz
tar -xvf nexus-3.16.2-01-unix.tar.gz
mv -f nexus-3.16.2-01 nexus
echo "Install Nexus OSS - add nexus user"
useradd nexus
chown -R nexus:nexus /opt/nexus/
ln -s /opt/nexus/nexus/bin/nexus /etc/init.d/nexus
cd /etc/init.d
chkconfig --add nexus
chkconfig --levels 345 nexus on
echo "Before Comment. "
chmod -f 777 /tmp/nexus.rc 
mv -f /tmp/nexus.rc /opt/nexus/nexus/bin/nexus.rc
echo "Install Nexus OSS - restart Nexus"
service nexus restart

echo "Install Nexus OSS - checking if nexus is up"
until $(curl --output /dev/null --silent --head --fail http://localhost:8081); do
    printf '.'
    sleep 2
done

echo "Install Nexus OSS - Waking up - Nexus is up"
echo "Done running setup script"
