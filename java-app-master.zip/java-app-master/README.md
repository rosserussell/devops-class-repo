

<H1>README</H1>
<H1>Repo Name: java-app</H1>
<P>Purpose: To demostrate how to use Jenkinsfile and POM files to create a Dev Ops Build Pipeline. 
This repo will stage and build the java application, run the unit test, publish the artifacts to a Nexus artifactory, and then download them to create an AMI image using Packer. </P>

<H1>Before running this repo on your own repository:</H1>

<UL>
<LI>Update the Jenkins File to specify your own Nexus Repository URL (1 location)
<LI>Update the jenkinsfile to specify your own GitHub Repo URL and name (1 location)
<LI>Update the POM file to specify your own Nexus URL or IP (3 locations)
<LI>Update the Nexus credential ID on the Jenkinsfile to reflect the Nexus credentials ID on your Jenkins Credentials  (1 locatioin)
<LI>Update the download script download-artifacts.sh located in /usr/local/bin on the Jenkins server to specify your own Nexus URL or IP (1 location)
</UL>
  
<H1>Additional Configuration:</H1>

<UL>
<LI>Add your Jenkins IP webhook to each repo

<H1>version 1.0.0 </H1>
