Nexus will download the war files on this directory.
