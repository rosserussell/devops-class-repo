#!/bin/bash
echo "sudo apt update"
sudo apt-get update

# Install tomcat
echo "sudo apt-get install -y default-jdk"
sudo apt-get update

echo "sudo apt-get install -y tomcat8"
sudo apt-get install -y tomcat8

echo "sudo apt-get install -y tomcat8-docs tomcat8-examples tomcat8-admin"
sudo apt-get install -y tomcat8-docs tomcat8-examples tomcat8-admin

# Install firewall
echo "sudo apt-get install -y ufw"
sudo apt-get install -y ufw
